// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Search the bookmarks when entering the search keyword.
$(function() {
    $.ajax({
            method: 'post',
            url: "http://82.81.238.36/LeviConvert/PublicConversion.aspx",
            data: {
                'txtSearch': '19018',
                '__EVENTTARGET': 'txtSearch',
                'ddlPriceList': '03/18',
                'ddlYear0': '2015',
                '__EVENTVALIDATION': 'W9lMcUt2grZALWi9dS2P3UNmpolIZdiMzq7oen+jqvid8za4uYgSTnBh0K6K/oNX9fip2GRnTK9mn7tHVJ8Eej/p5Z8fYefMH7w3zmCDb55vYvzQXidNyLqspKqWzemZREXHxI+XQqnF3lFWcKOmNf8nn6Z8f6XNC/OeYZHqCQQeA8+I6mqArkiT33TYiM/dUTHFqdqCFszjAZqC0C1Icst1zdvK7V5uqk507HeXRQFA7WBXFwXBzGFjjTBgu1sVw66hoD07yrZLv83ANtirQBXxiXBK3jMhwkg9S9/KNoic44MCoxlXMYyIoJRTBuGk0Pecxxt+YTGT5pLsdg/f1Qjr0XyvtFZ337VLQ5DChXC0WJjD9w72oxV54n/T5UPw59zO7bX7xmKaxt7OmNHllg==',
                '__EVENTARGUMENT': '',
                '__LASTFOCUS': '',
                '__VIEWSTATE': 'MrwcBD6DhQMGuFJpD4jX0+x/3xc3n18YQfvWPAaMw2kPVTgrY3sr/aat9jPkffi8sMd971a7wcT88uQeInkqAIsJBzVRXetDBSYBbuatBDxDHZmxV7zashqFmoJmJsCU+F+cfDwRzoJ7tMvfuvsFMcWLihZ1ZjT7G7nji0s2gW/GmGqcC/1fmEy6oq5UjMDp+ke3QQ4x8c6L0XVS+7JbjnQGWhCrIEZCVNfksq5OPXPPAjx5LmDucrGZzZ5U8pmxTjyOmE9rQTpemto3FooJcQoFVvuO8U/KpaY0Un09YLA5E7ieEeqWgH4cd9o3XdpefLahT0d5ff1C136TnUhoj/a7SDtg33GMpIX8pcYNN548UbeiGYorRkAN3Ip72OYwwmwlE5uz1F1g6gyhEwhTuSG22h+7EVFPGEiV8mCgN3ClAcIAXMAfiBgfQCUaZjCxEKZSKbtcrNO6zOnuIC+TkHkVh75MBHt8u+56OdXkLm618SaJWpeviuTX7vdh0xiPlNOU3pRhxwOvrXfnLQmICTYR4Nv1Ihdf9aEaY9FT3I1GYlWkiKAGcEYeC8dU1rTMg6sD3+RFICJpKZKdIUrIBbT4PWUQyERwQXeJAs4GWXv8D71FewwhI72OzGZc0XaGlo3q8k3rs6sMqY+QMAmnvOARAnI3jzSYGa+x004qATx7QmJC3uSHAFXGLZYEZpJapqrBzXGod2NWm5mPUMKGez+Ir/yo/pGlFN5GigmP9rXWOZFE+znUqt2ipfXVYcv/28gEB/aw2ttUlVTXH6lgD4YYV04g/+91B9JbRXlg++EIpArd6DMK6QymWGR8AXtgo1IeTDjYcs7L/6yOC8tL1PW1/aGMYDDss3/CJqACxjTeG+a4ygwSGZ3PnLKs8P7VZ0GfJ/mXAVk0BjVLsivtKMBYyjpK4Sd0OnMQxV4YAcFewfqOq9VocTOao8klXGUTVOuJL3UdbOTlRwUADNYnr2XyzReq3GSdYidiv9LK2WOjjLgVuWECRlFZpASjE+KNTMaRYvRr0hjFoSDfjRZQ/0x0t+ebU4RmbFJzAyxnw++5FPCepNim9UsdRPIMj0aU23ArglhR+t3u2hCRpwrjKnpwWue7mospJsYw5v+KM6JiGivCruPSQI0K/KD73cRECQf7qXC6dclnSz3kRvQTAOcShEB0sNFiOik8IYriXmgRJPuWBN0fC8zOkI2Dmb8s+IK5bZj05BD3gQFyHeIysINXZsL55SEty5Jpv1OVC4EzStxQRhArvNnEIGqzyvoAG+2F+NG49kX4Wz2ZYKuem2JOPPxP+fMnBADhkCG5KPUYt83ADLs7CSMv4RobucAU',
                '__VIEWSTATEGENERATOR': 'BA761583',
                '__VIEWSTATEENCRYPTED': '',
                'btnConvertCodeLevi': '',
                'MaskedRishui_ClientState': ''
            }, success: function (result) {
                console.log(result)
            }
        }
    )


});
