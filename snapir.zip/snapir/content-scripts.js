// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Search the bookmarks when entering the search keyword.
// jQuery(function () {


var $ = jQuery.noConflict();
var year = '';

console.log('running');
get_next_records();

function get_next_records() {

    if (localStorage.getItem('process')) {
        console.log(document.getElementById('txtSearch').value);
        run_record();
    } else {
        localStorage.setItem('process', JSON.stringify(1));
        $.ajax({
            method: "GET",
            url: "http://sandbox.sogo.co.il/hova/wp-content/themes/sogo-child/db.php",
            dataType: "JSON"
        })
            .fail(function (jqXHR, textStatus) {
                alert("Request failed: " + textStatus);
            })
            .done(function (msg) {
                console.log(msg);
                localStorage.setItem('code_levi', JSON.stringify(msg[0].code_levi));
                localStorage.setItem('year', JSON.stringify(msg[0].year));
                run_record();

            });
    }

}

function run_record() {
    var last = 'oren';


    var int = setInterval(function () {

            var pnl = $('#pnlCodeLevi').text().trim();
            var form = $('#form1');

            year = JSON.parse(localStorage.getItem('year'));
            code = JSON.parse(localStorage.getItem('code_levi'));
            process = localStorage.getItem('process');


            switch (process) {
                case "2":
                    document.getElementById('ddlYear0').value = year;
                    localStorage.setItem('process', JSON.stringify(3));
                    form.submit();

                    break;
                case "3":
                    localStorage.setItem('pnl', JSON.stringify(pnl));
                    document.getElementById('btnConvertCodeLevi').click();
                    localStorage.setItem('process', JSON.stringify(4));
                    break;
                case "4":
                    if (pnl != JSON.parse(localStorage.getItem('pnl'))) {
                        clearInterval(int);
                        parse_return();
                        console.log('done ');
                    }
                    break;
                default:
                    document.getElementById('txtSearch').value = code;
                    localStorage.setItem('process', JSON.stringify(2));
                    form.submit();
            }


        }

        ,
        2000
        )
    ;
}


// function __doPostBack(eventTarget, eventArgument) {
//     if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
//         theForm.__EVENTTARGET.value = eventTarget;
//         theForm.__EVENTARGUMENT.value = eventArgument;
//         theForm.submit();
//     }
// }
function parse_return() {

    localStorage.removeItem('process');
    localStorage.removeItem('code_levi');
    localStorage.removeItem('year');
    localStorage.removeItem('pnl');
    var $tableData = [];

    var $rows = $('#pnlCodeLevi').find('table tr');

    $rows.each(function (i) {

        var cells = $(this).find('td');
        var $cells_data = [];

        cells.each(function (j) {
            $cells_data[j] = this.textContent;
        });

        $tableData.push($cells_data);

    });

    $.ajax({
        method: "POST",
        url: "http://sandbox.sogo.co.il/hova/wp-content/themes/sogo-child/db1.php",
        data: {
            // 'table' : $('#pnlCodeLevi').find('table').html(),
            'table': JSON.stringify($tableData),
            'code': $('#txtSearch').val(),
            'year': year,
        }
    })
        .fail(function (jqXHR, textStatus) {
            alert("Request failed: " + textStatus);
        })
        .done(function (msg) {
            console.log('start again');
            console.log(msg);
            get_next_records();
        });
}


// // do the first run
// $('#txtSearch').val(a[0][0]);
// $('#lblYear0').val(a[0][1]);
// $('#btnConvertCodeLevi').trigger('click');
// console.log("click on : " + a[0][0] + " : " + a[0][1]);
// var index = 1;
// var int = setInterval(function(){
//     // wait for the answer from the browser
//     // if we got answer parse it and continue - otherwise keep waiting
//
//     var pnl = $('#pnlCodeLevi').text();
//     if(last == pnl ){
//         return false;
//     }
//     console.log(pnl);
//     if(a.length > index){
//         $('#txtSearch').val(a[index][0]);
//         $('#lblYear0').val(a[index][1]);
//         $('#btnConvertCodeLevi').trigger('click');
//         console.log("click on : " + a[index][0] + " : " + a[index][1]);
//     }else{
//         clearInterval(int);
//         console.log('done ');
//     }
//     index++;
// }, 3000);


// a.forEach(function (value, index) {
//     console.log(value[0]);
//     console.log(value[1]);
//     $('#txtSearch').val(value[0]);
//     $('#lblYear0').val(value[1]);
//     $('#btnConvertCodeLevi').trigger('click');
//     setTimeout()
//
// });

// $(document).ajaxStop(function () {
//     // 0 === $.active
// });

//jQuery('#btnConvertCodeLevi').trigger('click');
// jQuery.ajax({
//         method: 'post',
//         // crossDomain: true,
//         url: "http://www.snapir.co.il/leviconvert/PublicConversion.aspx",
//         data: {
//             'txtSearch': '19018',
//             '__EVENTTARGET': 'txtSearch',
//             'ddlPriceList': '03/18',
//             'ddlYear0': '2015',
//             '__EVENTVALIDATION': 'W9lMcUt2grZALWi9dS2P3UNmpolIZdiMzq7oen+jqvid8za4uYgSTnBh0K6K/oNX9fip2GRnTK9mn7tHVJ8Eej/p5Z8fYefMH7w3zmCDb55vYvzQXidNyLqspKqWzemZREXHxI+XQqnF3lFWcKOmNf8nn6Z8f6XNC/OeYZHqCQQeA8+I6mqArkiT33TYiM/dUTHFqdqCFszjAZqC0C1Icst1zdvK7V5uqk507HeXRQFA7WBXFwXBzGFjjTBgu1sVw66hoD07yrZLv83ANtirQBXxiXBK3jMhwkg9S9/KNoic44MCoxlXMYyIoJRTBuGk0Pecxxt+YTGT5pLsdg/f1Qjr0XyvtFZ337VLQ5DChXC0WJjD9w72oxV54n/T5UPw59zO7bX7xmKaxt7OmNHllg==',
//             '__EVENTARGUMENT': '',
//             '__LASTFOCUS': '',
//             '__VIEWSTATE': 'MrwcBD6DhQMGuFJpD4jX0+x/3xc3n18YQfvWPAaMw2kPVTgrY3sr/aat9jPkffi8sMd971a7wcT88uQeInkqAIsJBzVRXetDBSYBbuatBDxDHZmxV7zashqFmoJmJsCU+F+cfDwRzoJ7tMvfuvsFMcWLihZ1ZjT7G7nji0s2gW/GmGqcC/1fmEy6oq5UjMDp+ke3QQ4x8c6L0XVS+7JbjnQGWhCrIEZCVNfksq5OPXPPAjx5LmDucrGZzZ5U8pmxTjyOmE9rQTpemto3FooJcQoFVvuO8U/KpaY0Un09YLA5E7ieEeqWgH4cd9o3XdpefLahT0d5ff1C136TnUhoj/a7SDtg33GMpIX8pcYNN548UbeiGYorRkAN3Ip72OYwwmwlE5uz1F1g6gyhEwhTuSG22h+7EVFPGEiV8mCgN3ClAcIAXMAfiBgfQCUaZjCxEKZSKbtcrNO6zOnuIC+TkHkVh75MBHt8u+56OdXkLm618SaJWpeviuTX7vdh0xiPlNOU3pRhxwOvrXfnLQmICTYR4Nv1Ihdf9aEaY9FT3I1GYlWkiKAGcEYeC8dU1rTMg6sD3+RFICJpKZKdIUrIBbT4PWUQyERwQXeJAs4GWXv8D71FewwhI72OzGZc0XaGlo3q8k3rs6sMqY+QMAmnvOARAnI3jzSYGa+x004qATx7QmJC3uSHAFXGLZYEZpJapqrBzXGod2NWm5mPUMKGez+Ir/yo/pGlFN5GigmP9rXWOZFE+znUqt2ipfXVYcv/28gEB/aw2ttUlVTXH6lgD4YYV04g/+91B9JbRXlg++EIpArd6DMK6QymWGR8AXtgo1IeTDjYcs7L/6yOC8tL1PW1/aGMYDDss3/CJqACxjTeG+a4ygwSGZ3PnLKs8P7VZ0GfJ/mXAVk0BjVLsivtKMBYyjpK4Sd0OnMQxV4YAcFewfqOq9VocTOao8klXGUTVOuJL3UdbOTlRwUADNYnr2XyzReq3GSdYidiv9LK2WOjjLgVuWECRlFZpASjE+KNTMaRYvRr0hjFoSDfjRZQ/0x0t+ebU4RmbFJzAyxnw++5FPCepNim9UsdRPIMj0aU23ArglhR+t3u2hCRpwrjKnpwWue7mospJsYw5v+KM6JiGivCruPSQI0K/KD73cRECQf7qXC6dclnSz3kRvQTAOcShEB0sNFiOik8IYriXmgRJPuWBN0fC8zOkI2Dmb8s+IK5bZj05BD3gQFyHeIysINXZsL55SEty5Jpv1OVC4EzStxQRhArvNnEIGqzyvoAG+2F+NG49kX4Wz2ZYKuem2JOPPxP+fMnBADhkCG5KPUYt83ADLs7CSMv4RobucAU',
//             '__VIEWSTATEGENERATOR': 'BA761583',
//             '__VIEWSTATEENCRYPTED': '',
//             'btnConvertCodeLevi': '',
//             'MaskedRishui_ClientState': ''
//         }, success: function (result) {
//             console.log(result)
//         }
//     }
// )


// });

